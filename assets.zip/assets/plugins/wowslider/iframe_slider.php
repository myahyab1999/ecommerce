<!-- Start WOWSlider.com -->
<iframe src="slider.php" style="width:660px;height:349px;max-width:100%;overflow:hidden;border:none;padding:0;margin:0 auto;display:block;" marginheight="0" marginwidth="0"></iframe>
<!-- End WOWSlider.com -->
