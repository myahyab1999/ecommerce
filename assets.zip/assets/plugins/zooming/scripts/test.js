const open = require('open')

open(__dirname + '/../test.html')
