*For feature request or questions (please make sure to read through [Documentation](http://desmonding.me/zooming/docs/index.html)), ignore everything below.*

Make sure the issue can be reproduced in either [demo](http://desmonding.me/zooming/) page or a forked [codepen](https://codepen.io/kingdido999/pen/rpYrKV) page.

--- Remove this line and above ---

- URL to reproduce the issue: http://desmonding.me/zooming/
- OS: (Windows, OSX, Linux, iOS, Android...)
- Browser and version: (Chrome, Firefox, Safari, IE...)

Steps to reproduce:

1.
